module Tests where

import Piedras
import Test.Tasty (defaultMain, testGroup)
import Test.Tasty.HUnit (assertEqual, testCase)


main = defaultMain unitTests

unitTests = TestGroup "Unit tests" [testOtroJugadorH, testOtroJugadorC]

testOtroJugadorH =
  TestCase (assertEqual "for (otroJugadorH H)" C (otroJugador H))

testOtroJugadorC =
  TestCase (assertEqual "for (otroJugadorC 1)" H (otroJugador C))
